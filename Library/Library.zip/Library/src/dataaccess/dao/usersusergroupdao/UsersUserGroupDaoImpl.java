package dataaccess.dao.usersusergroupdao;

import data.entity.UsersUserGroup;

import java.util.List;

public class UsersUserGroupDaoImpl implements UsersUserGroupDao {
    @Override
    public UsersUserGroup save(UsersUserGroup entity) {
        return null;
    }

    @Override
    public List<UsersUserGroup> save(List<UsersUserGroup> entity) {
        return null;
    }

    @Override
    public UsersUserGroup update(UsersUserGroup entity) {
        return null;
    }

    @Override
    public List<UsersUserGroup> update(List<UsersUserGroup> entity) {
        return null;
    }

    @Override
    public void delete(long id) {

    }

    @Override
    public void delete(UsersUserGroup entity) {

    }

    @Override
    public void delete(List<Long> idList) {

    }

    @Override
    public List<UsersUserGroup> find() {
        return null;
    }

    @Override
    public UsersUserGroup find(long id) {
        return null;
    }
}
