package dataaccess.dao.usergroupstatusdao;

import data.entity.UserGroupStatus;

import java.util.List;

public class UserGroupStatusDaoImpl implements UserGroupStatusDao{
    @Override
    public UserGroupStatus save(UserGroupStatus entity) {
        return null;
    }

    @Override
    public List<UserGroupStatus> save(List<UserGroupStatus> entity) {
        return null;
    }

    @Override
    public UserGroupStatus update(UserGroupStatus entity) {
        return null;
    }

    @Override
    public List<UserGroupStatus> update(List<UserGroupStatus> entity) {
        return null;
    }

    @Override
    public void delete(long id) {

    }

    @Override
    public void delete(UserGroupStatus entity) {

    }

    @Override
    public void delete(List<Long> idList) {

    }

    @Override
    public List<UserGroupStatus> find() {
        return null;
    }

    @Override
    public UserGroupStatus find(long id) {
        return null;
    }
}
