package dataaccess.dao.userstatusdao;

import data.entity.UserStatus;

import java.util.List;

public class UserStatusDaoImpl implements UserStatusDao{
    @Override
    public UserStatus save(UserStatus entity) {
        return null;
    }

    @Override
    public List<UserStatus> save(List<UserStatus> entity) {
        return null;
    }

    @Override
    public UserStatus update(UserStatus entity) {
        return null;
    }

    @Override
    public List<UserStatus> update(List<UserStatus> entity) {
        return null;
    }

    @Override
    public void delete(long id) {

    }

    @Override
    public void delete(UserStatus entity) {

    }

    @Override
    public void delete(List<Long> idList) {

    }

    @Override
    public List<UserStatus> find() {
        return null;
    }

    @Override
    public UserStatus find(long id) {
        return null;
    }
}
