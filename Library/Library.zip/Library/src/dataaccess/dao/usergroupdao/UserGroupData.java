package dataaccess.dao.usergroupdao;

import data.entity.UserGroup;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UserGroupData {
    public static List<UserGroup> userGroups = new ArrayList<>();
    public static Map<Long,UserGroup> userGroupMap;
}
