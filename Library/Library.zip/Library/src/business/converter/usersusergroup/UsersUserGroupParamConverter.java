package business.converter.usersusergroup;

import data.entity.UsersUserGroup;

public interface UsersUserGroupParamConverter {
    UsersUserGroup convert(UsersUserGroupParam param);
}
