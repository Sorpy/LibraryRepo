package business.converter.usersusergroup;

import data.entity.UsersUserGroup;

public class UsersUserGroupResultConverterImpl implements UsersUserGroupResultConverter {
    @Override
    public UsersUserGroupResult convert(UsersUserGroup param) {
        return null;
    }
}
