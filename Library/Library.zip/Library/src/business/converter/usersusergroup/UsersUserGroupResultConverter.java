package business.converter.usersusergroup;

import data.entity.UsersUserGroup;

public interface UsersUserGroupResultConverter {

    UsersUserGroupResult convert(UsersUserGroup param);
}
