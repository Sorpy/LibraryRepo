package business.converter.usersusergroup;

import business.converter.BaseNamedParam;

public class UsersUserGroupParam  extends BaseNamedParam {
}
