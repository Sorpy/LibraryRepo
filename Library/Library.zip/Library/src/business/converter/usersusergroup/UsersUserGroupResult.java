package business.converter.usersusergroup;

import business.converter.BaseNamedResult;

public class UsersUserGroupResult extends BaseNamedResult {
}
