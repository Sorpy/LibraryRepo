package business.converter.userstatus;

import business.converter.BaseNamedResult;

public class UserStatusResult extends BaseNamedResult {
}
