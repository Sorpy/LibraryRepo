package business.converter.userstatus;

import data.entity.UserStatus;

public class UserStatusResultConverterImpl implements UserStatusResultConverter {
    @Override
    public UserStatusResult convert(UserStatus param) {
        return null;
    }
}
