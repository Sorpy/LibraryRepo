package business.converter.userstatus;

import business.converter.BaseNamedParam;

public class UserStatusParam  extends BaseNamedParam {
}
