package business.converter.userstatus;

import data.entity.UserStatus;

public interface UserStatusParamConverter {
    UserStatus convert(UserStatusParam param);

}
