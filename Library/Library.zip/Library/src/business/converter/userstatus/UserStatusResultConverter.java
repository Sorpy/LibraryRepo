package business.converter.userstatus;

import data.entity.UserStatus;

public interface UserStatusResultConverter {
    UserStatusResult convert(UserStatus param);
}
