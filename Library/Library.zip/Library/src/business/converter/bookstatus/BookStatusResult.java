package business.converter.bookstatus;

import business.converter.BaseNamedResult;

public class BookStatusResult extends BaseNamedResult {
}
