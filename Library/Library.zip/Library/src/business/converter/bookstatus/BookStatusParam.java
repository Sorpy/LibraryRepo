package business.converter.bookstatus;

import business.converter.BaseNamedParam;

public class BookStatusParam  extends BaseNamedParam {
}
