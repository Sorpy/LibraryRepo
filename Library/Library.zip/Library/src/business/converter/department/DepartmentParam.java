package business.converter.department;

import business.converter.BaseNamedParam;

public class DepartmentParam  extends BaseNamedParam {
}
