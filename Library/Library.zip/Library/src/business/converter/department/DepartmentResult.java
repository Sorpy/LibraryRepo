package business.converter.department;

import business.converter.BaseNamedResult;

public class DepartmentResult extends BaseNamedResult {
}
