package business.converter;

public class IllegalConvertException extends Exception {
    public IllegalConvertException(String message) {
        super(message);
    }
}

