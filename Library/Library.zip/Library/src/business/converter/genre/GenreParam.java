package business.converter.genre;

import business.converter.BaseNamedParam;

public class GenreParam  extends BaseNamedParam {
}
