package business.converter.genre;

import business.converter.BaseNamedResult;

public class GenreResult extends BaseNamedResult {
}
