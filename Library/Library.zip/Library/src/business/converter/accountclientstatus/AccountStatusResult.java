package business.converter.accountclientstatus;

import business.converter.BaseNamedResult;

public class AccountStatusResult extends BaseNamedResult {
}
