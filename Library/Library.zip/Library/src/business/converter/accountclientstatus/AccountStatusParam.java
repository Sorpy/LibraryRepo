package business.converter.accountclientstatus;

import business.converter.BaseNamedParam;

public class AccountStatusParam extends BaseNamedParam {
}
