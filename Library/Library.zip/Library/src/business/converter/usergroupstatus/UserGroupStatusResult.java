package business.converter.usergroupstatus;

import business.converter.BaseNamedResult;

public class UserGroupStatusResult extends BaseNamedResult {
}
