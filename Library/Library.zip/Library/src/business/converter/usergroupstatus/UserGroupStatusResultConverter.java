package business.converter.usergroupstatus;

import data.entity.UserGroupStatus;

public interface UserGroupStatusResultConverter {
    UserGroupStatusResult convert(UserGroupStatus param);
}
