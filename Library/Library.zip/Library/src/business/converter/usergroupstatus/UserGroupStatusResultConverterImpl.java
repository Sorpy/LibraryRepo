package business.converter.usergroupstatus;

import data.entity.UserGroupStatus;

public class UserGroupStatusResultConverterImpl implements UserGroupStatusResultConverter {
    @Override
    public UserGroupStatusResult convert(UserGroupStatus param) {
        return null;
    }
}
