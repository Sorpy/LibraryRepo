package business.converter.usergroupstatus;

import business.converter.BaseNamedParam;

public class UserGroupStatusParam  extends BaseNamedParam {
}
