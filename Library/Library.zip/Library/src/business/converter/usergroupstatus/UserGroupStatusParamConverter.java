package business.converter.usergroupstatus;

import data.entity.UserGroupStatus;

public interface UserGroupStatusParamConverter {
    UserGroupStatus convert(UserGroupStatusParam param);
}
