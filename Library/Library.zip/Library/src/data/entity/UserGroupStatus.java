package data.entity;

public class UserGroupStatus extends PersistentNamed {
}
