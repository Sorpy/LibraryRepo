package data.entity;

public class Genre extends PersistentNamed {
}
