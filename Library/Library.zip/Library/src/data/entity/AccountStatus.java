package data.entity;

public class AccountStatus extends PersistentNamed {
}
