package data.entity;

public class BookStatus extends PersistentNamed {
}
