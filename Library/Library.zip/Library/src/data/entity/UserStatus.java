package data.entity;

public class UserStatus extends PersistentNamed {
}
