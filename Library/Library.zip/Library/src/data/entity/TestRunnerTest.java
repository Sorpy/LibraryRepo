package data.entity;

import static org.junit.jupiter.api.Assertions.*;

class TestRunnerTest {

    @org.junit.jupiter.api.Test
    void test1() {
    }
}