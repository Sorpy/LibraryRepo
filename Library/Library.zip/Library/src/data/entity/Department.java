package data.entity;

public class Department extends PersistentNamed {
}
